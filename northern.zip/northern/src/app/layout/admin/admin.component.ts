import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router'
@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.scss']
})
export class AdminComponent implements OnInit {
  title = 'Northern Arc';
  currentUrl: string;
  constructor(private router:Router) { 
    router.events.subscribe((_:NavigationEnd) => this.currentUrl = _.url);
  }

  ngOnInit() {
  }

}
