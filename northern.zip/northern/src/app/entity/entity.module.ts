import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { EntityRoutingModule } from './entity-routing.module';
import { EntityListComponent } from './entity-list/entity-list.component';
import { AddEntityComponent } from './add-entity/add-entity.component';

@NgModule({
  imports: [
    CommonModule,
    EntityRoutingModule
  ],
  declarations: [EntityListComponent, AddEntityComponent]
})
export class EntityModule { }
