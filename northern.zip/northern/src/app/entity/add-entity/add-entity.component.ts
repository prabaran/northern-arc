import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-entity',
  templateUrl: './add-entity.component.html',
  styleUrls: ['./add-entity.component.scss']
})
export class AddEntityComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
