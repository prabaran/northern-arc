import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../services/api.service';
import { Observable } from 'rxjs';
@Component({
  selector: 'app-entity-list',
  templateUrl: './entity-list.component.html',
  styleUrls: ['./entity-list.component.scss']
})
export class EntityListComponent implements OnInit {
  userList: any;
  constructor(private apiService: ApiService) {
    
   }

  ngOnInit() {
    this.apiService.getUsers().subscribe(data => this.userList = data);
  }

}
